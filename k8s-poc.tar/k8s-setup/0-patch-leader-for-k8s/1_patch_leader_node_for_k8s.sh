#!/bin/bash
set -eou pipefail

source ../config/conjur-k8s.config
source ../bin/conjur_utils.sh

# This script enables authn-k8s in a running Conjur node (Master or Follower) running in Docker.
# It's useful for enabling authn-k8s after standing the node up.
# It must be run on the host where the Conjur node is running.
# It does NOT need to use kubectl or oc.

#################
main() {
  configure_authn_k8s
  wait_till_node_is_responsive
  curl -k $CONJUR_LEADER_URL/info
  update_follower_cert
}

###################################
configure_authn_k8s() {
  echo "Initializing Conjur K8s authentication policies..."

  cp ./templates/master-seed-generation-policy.template.yaml ./policy/master-seed-generation-policy.yaml
  conjur_append_policy root ./policy/master-seed-generation-policy.yaml

  cat ./templates/master-authenticator-policy.template.yaml           	\
  | sed -e "s#{{ CLUSTER_AUTHN_ID }}#$CLUSTER_AUTHN_ID#g"            	\
  | sed -e "s#{{ CYBERARK_NAMESPACE_NAME }}#$CYBERARK_NAMESPACE_NAME#g" \
  > ./policy/master-authenticator-policy.yaml
  conjur_append_policy root ./policy/master-authenticator-policy.yaml delete

  if $REMOTE_CONJUR_LEADER; then
    interpreter="ssh -i $SSH_PVT_KEY $SSH_USERNAME@$CONJUR_LEADER_HOSTNAME"
  else
    interpreter=bash
  fi

#  $interpreter <<EOF

# create CA
$DOCKER exec $CONJUR_LEADER_CONTAINER_NAME				\
        chpst -u conjur conjur-plugin-service possum			\
        rake authn_k8s:ca_init["conjur/authn-k8s/$CLUSTER_AUTHN_ID"]

$DOCKER exec $CONJUR_LEADER_CONTAINER_NAME				\
        evoke variable set CONJUR_AUTHENTICATORS authn-k8s/$CLUSTER_AUTHN_ID
#EOF

}

############################
wait_till_node_is_responsive() {
  set +e
  node_is_healthy=""
  while [[ "$node_is_healthy" == "" ]]; do
    sleep 2
    node_is_healthy=$(curl -sk $CONJUR_LEADER_URL/health | grep "ok" | tail -1 | grep "true")
  done
  set -e
}

############################
update_follower_cert() {

  rm -f $FOLLOWER_CERT_FILE
  $DOCKER exec $CONJUR_LEADER_CONTAINER_NAME \
        bash -c "evoke ca issue -f conjur-follower $CONJUR_FOLLOWER_SERVICE_NAME"
  $DOCKER exec $CONJUR_LEADER_CONTAINER_NAME cat /opt/conjur/etc/ssl/conjur-follower.pem > $FOLLOWER_CERT_FILE
}

main "$@"
