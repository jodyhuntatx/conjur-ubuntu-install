#!/bin/bash -e
source ../../../config/conjur.config

cat templates/secrets.template.yml				\
  | sed -e "s#{{ ACCOUNT_USERNAME }}#$ACCOUNT_USERNAME#g"       \
  | sed -e "s#{{ ACCOUNT_PASSWORD }}#$ACCOUNT_PASSWORD#g"       \
  > secrets.yml

cat templates/mysql_REST.template.sh				\
  | sed -e "s#{{ ACCOUNT_USERNAME }}#$ACCOUNT_USERNAME#g"       \
  | sed -e "s#{{ ACCOUNT_PASSWORD }}#$ACCOUNT_PASSWORD#g"       \
  > mysql_REST.sh

docker build -t $APP_IMAGE .
